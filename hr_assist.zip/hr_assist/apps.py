from django.apps import AppConfig


class HrAssistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hr_assist'
